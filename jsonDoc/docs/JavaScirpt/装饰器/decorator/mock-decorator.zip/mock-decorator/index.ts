import { fakerBehaviorKey } from './decorator/fake.decorator';
import { typeKeys } from './decorator/type.decorator';
import { MockDataStore } from './MockDataStore';

// faker
const handleFakeBehavior = (data) => {
  let fakerBehavior
  if (fakerBehavior = data[fakerBehaviorKey]) {
    return fakerBehavior.mockFn(...fakerBehavior.params);
  }
  return;
}

// array
const handleArrayBehavior = (data) => {
  let arrayBehavior
  if (arrayBehavior = data[typeKeys.isArrayKey]) {
    const { length, max = 100, min = 0 } = arrayBehavior;
    if (!!length) {
      return length;
    } else {
      return Math.ceil(Math.random() * (max - min) + min);
    }
  }
  return undefined;
}

// obj
const handleObjectBehavior = (data) => {
  let objectBehavior
  if (objectBehavior = data[typeKeys.isObjectKey]) {
    const { target } = objectBehavior;

    return handleMockBehavior(target);
  }
  return;
};

// enum
const handleEnumBehavior = (data) => {
  let enumBehavior
  if (enumBehavior = data[typeKeys.isEnumKey]) {
    const { values } = enumBehavior;

    const length = values.length;

    return values[Math.floor(Math.random() * length)];
  }
  return;
};

const handleNumberBehavior = (data) => {
  let numberBehavior
  if (numberBehavior = data[typeKeys.isNumberKey]) {
    const { max, min, isInt } = numberBehavior;
    let result = Math.random() * (max - min) + min;

    return isInt ? Math.floor(result) : result;
  }
  return
}

const handleValueBehaviors = (data) => {
  let result;
  result = handleObjectBehavior(data);
  result = result ?? handleNumberBehavior(data);
  result = result ?? handleFakeBehavior(data);
  result = result ?? handleEnumBehavior(data);

  return result;
}

export const handleMockBehavior = (target: Function) => {

  const targetData = MockDataStore.instance.getMockData(target);
  const targetInstance = {};

  if (!targetData) return

  Object.keys(targetData).forEach((key) => {
    if (targetData[key]) {
      const length = handleArrayBehavior(targetData[key]);
      if (!!length) {
        // 是数组
        const result = [];
        for(let i = 0; i<length ;++i) {
          result.push(handleValueBehaviors(targetData[key]));
        }
        targetInstance[key] = result;
      } else {
        targetInstance[key] = handleValueBehaviors(targetData[key]);
      }
    }
  });

  return targetInstance;
}

